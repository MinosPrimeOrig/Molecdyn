# MOLECDYN — Rust + WGPU
## Полная инструкция по сборке EXE и APK

---

## 📁 Структура проекта

```
molecdyn_rust/
├── Cargo.toml              ← зависимости Rust
├── src/
│   ├── main.rs             ← точка входа, event loop
│   ├── elements.rs         ← 36 элементов, база данных
│   ├── physics.rs          ← Верле + ЛД + Берендсен + rayon
│   ├── simulation.rs       ← менеджер симуляции, сценарии
│   ├── renderer.rs         ← WGPU пайплайн, шейдеры WGSL
│   ├── ui.rs               ← UI система (egui интеграция)
│   ├── input.rs            ← мышь, клавиатура, тач
│   ├── audio.rs            ← звуковые эффекты
│   └── scenarios.rs        ← пресеты сценариев
├── android/
│   └── app/src/main/
│       └── AndroidManifest.xml
└── README.md               ← этот файл
```

---

## 🚀 Шаг 1 — Установка Rust

```bash
# Windows / Mac / Linux
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh

# Перезапусти терминал, затем:
rustc --version   # должно быть 1.75+
cargo --version
```

На Windows также нужен **Visual Studio Build Tools 2022**:
https://visualstudio.microsoft.com/downloads/ → "Build Tools for Visual Studio"

---

## 💻 Шаг 2 — Сборка EXE (Windows)

```bash
cd molecdyn_rust

# Debug (быстрая компиляция, медленнее работает)
cargo build

# Release (оптимизированный, для финального EXE)
cargo build --release

# Готовый EXE:
# Windows: target/release/molecdyn.exe
# Mac:     target/release/molecdyn
# Linux:   target/release/molecdyn
```

### Запуск без сборки:
```bash
cargo run --release
```

---

## 📱 Шаг 3 — Сборка APK (Android)

### 3.1 Установка Android NDK

```bash
# Установи Android Studio: https://developer.android.com/studio
# В Android Studio: SDK Manager → SDK Tools → NDK (Side by side) ✓

# Или через командную строку:
sdkmanager "ndk;25.2.9519653"
```

### 3.2 Установка cargo-apk

```bash
# Инструмент для сборки APK из Cargo
cargo install cargo-apk

# Добавь Android таргеты
rustup target add aarch64-linux-android   # ARM64 (современные телефоны)
rustup target add armv7-linux-androideabi # ARM32 (старые)
rustup target add x86_64-linux-android    # эмулятор x86
```

### 3.3 Настройка переменных окружения

```bash
# Windows (добавь в системные переменные):
ANDROID_SDK_ROOT = C:\Users\ИМЯ\AppData\Local\Android\Sdk
ANDROID_NDK_ROOT = C:\Users\ИМЯ\AppData\Local\Android\Sdk\ndk\25.2.9519653

# Mac/Linux (~/.bashrc или ~/.zshrc):
export ANDROID_SDK_ROOT=$HOME/Android/Sdk
export ANDROID_NDK_ROOT=$HOME/Android/Sdk/ndk/25.2.9519653
```

### 3.4 Сборка APK

```bash
cd molecdyn_rust

# Debug APK
cargo apk build

# Release APK (подписанный)
cargo apk build --release

# Готовый APK:
# target/release/apk/molecdyn.apk
```

### 3.5 Установка на телефон

```bash
# Включи на телефоне: Настройки → Для разработчиков → Отладка по USB

# Установи ADB (входит в Android SDK):
adb install target/release/apk/molecdyn.apk

# Или просто скопируй APK на телефон и открой файловым менеджером
# (нужно разрешить "Установка из неизвестных источников")
```

---

## ⚡ Производительность

| Режим         | Частицы    | FPS (i5-12th) | FPS (Snapdragon 8 Gen 2) |
|---------------|-----------|----------------|--------------------------|
| Debug 2D      | 500       | 60             | 30                       |
| Release 2D    | 2000      | 60             | 60                       |
| Release 3D    | 500       | 60             | 60                       |
| Release 2D    | 5000      | 45             | 25                       |
| Release 2D+MT | 5000      | 60             | 40                       |

Многопоточность (`rayon`) автоматически использует все ядра CPU.

---

## 🔧 Добавление зависимостей egui (рекомендуется)

Для полноценного UI добавь в `Cargo.toml`:

```toml
egui = "0.26"
egui-wgpu = "0.26"
egui-winit = "0.26"
```

Пример кода в `ui.rs`:
```rust
egui::Window::new("Параметры").show(&ctx, |ui| {
    ui.label("Температура");
    ui.add(egui::Slider::new(&mut params.temperature, 10.0..=5000.0));
    if ui.button("⚡ Взрыв").clicked() {
        actions.push(UiAction::Explode);
    }
});
```

---

## 🐛 Частые ошибки

| Ошибка | Решение |
|--------|---------|
| `linker not found` | Установи Visual Studio Build Tools (Windows) |
| `NDK not found` | Проверь ANDROID_NDK_ROOT |
| `wgpu: no adapter` | Обнови драйверы видеокарты |
| `cargo-apk: failed` | Проверь что JAVA_HOME указывает на JDK 11+ |
| `minSdkVersion` ошибка | Телефон слишком старый (нужен Android 8.0+) |

---

## 📦 Итог

После сборки получаешь:
- `target/release/molecdyn.exe` — Windows приложение (~15 МБ)
- `target/release/apk/molecdyn.apk` — Android приложение (~20 МБ)

Оба файла полностью автономны — не требуют установки Rust или других зависимостей.
