// ════════════════════════════════════════════════════════════════════
//  БАЗА ДАННЫХ ЭЛЕМЕНТОВ — 36 элементов
// ════════════════════════════════════════════════════════════════════

use glam::Vec3;

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum Category {
    Metal,
    Gas,
    NonMetal,
    Radioactive,
}

#[derive(Debug, Clone)]
pub struct Element {
    pub symbol: &'static str,
    pub name_ru: &'static str,
    pub atomic_number: u32,
    pub mass: f32,          // атомная масса, а.е.м.
    pub radius: f32,        // радиус для рендера (нм условно)
    pub tm: f32,            // температура плавления, K
    pub tb: f32,            // температура кипения, K
    pub color: [f32; 3],    // RGB 0..1
    pub lj_epsilon: f32,    // глубина потенциала ЛД (кДж/моль)
    pub lj_sigma: f32,      // характеристическое расстояние ЛД (Å)
    pub category: Category,
    pub description: &'static str,
}

impl Element {
    /// Фаза при данной температуре
    pub fn phase(&self, temperature: f32) -> Phase {
        if temperature < self.tm * 0.3 {
            Phase::Solid
        } else if temperature < self.tb * 0.5 {
            Phase::Liquid
        } else if temperature < self.tb * 5.0 {
            Phase::Gas
        } else {
            Phase::Plasma
        }
    }

    pub fn color_vec3(&self) -> Vec3 {
        Vec3::new(self.color[0], self.color[1], self.color[2])
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Phase {
    Solid,
    Liquid,
    Gas,
    Plasma,
}

impl Phase {
    pub fn name_ru(&self) -> &'static str {
        match self {
            Phase::Solid  => "ТВЁРДОЕ",
            Phase::Liquid => "ЖИДКОСТЬ",
            Phase::Gas    => "ГАЗ",
            Phase::Plasma => "ПЛАЗМА",
        }
    }

    pub fn color(&self) -> [f32; 3] {
        match self {
            Phase::Solid  => [0.53, 0.67, 1.0],
            Phase::Liquid => [0.0,  1.0,  0.53],
            Phase::Gas    => [1.0,  0.67, 0.27],
            Phase::Plasma => [1.0,  0.18, 0.42],
        }
    }
}

// ── Таблица всех элементов ──────────────────────────────────────────
pub static ELEMENTS: &[Element] = &[
    Element { symbol:"H",  name_ru:"Водород",   atomic_number:1,  mass:1.008,  radius:0.28, tm:14.0,   tb:20.0,   color:[0.86,0.93,1.00], lj_epsilon:0.66,  lj_sigma:2.4, category:Category::Gas,        description:"Лёгчайший элемент. При высокой T — плазма." },
    Element { symbol:"He", name_ru:"Гелий",     atomic_number:2,  mass:4.003,  radius:0.30, tm:0.95,   tb:4.2,    color:[0.67,0.93,1.00], lj_epsilon:0.08,  lj_sigma:2.6, category:Category::Gas,        description:"Инертный газ. Почти не взаимодействует." },
    Element { symbol:"Li", name_ru:"Литий",     atomic_number:3,  mass:6.941,  radius:0.46, tm:453.0,  tb:1615.0, color:[0.80,0.27,0.80], lj_epsilon:1.06,  lj_sigma:2.5, category:Category::Metal,      description:"Лёгкий щелочной металл." },
    Element { symbol:"Be", name_ru:"Бериллий",  atomic_number:4,  mass:9.012,  radius:0.40, tm:1560.0, tb:2742.0, color:[0.27,0.80,0.53], lj_epsilon:2.17,  lj_sigma:2.0, category:Category::Metal,      description:"Твёрдый лёгкий металл." },
    Element { symbol:"B",  name_ru:"Бор",       atomic_number:5,  mass:10.811, radius:0.38, tm:2349.0, tb:4200.0, color:[0.87,0.53,0.27], lj_epsilon:1.83,  lj_sigma:1.9, category:Category::NonMetal,   description:"Полуметалл с высокой Tm." },
    Element { symbol:"C",  name_ru:"Углерод",   atomic_number:6,  mass:12.011, radius:0.38, tm:3823.0, tb:4098.0, color:[0.53,0.53,0.53], lj_epsilon:2.41,  lj_sigma:3.4, category:Category::NonMetal,   description:"Основа органической химии." },
    Element { symbol:"N",  name_ru:"Азот",      atomic_number:7,  mass:14.007, radius:0.34, tm:63.0,   tb:77.0,   color:[0.40,0.53,1.00], lj_epsilon:1.22,  lj_sigma:3.3, category:Category::Gas,        description:"78% атмосферы Земли." },
    Element { symbol:"O",  name_ru:"Кислород",  atomic_number:8,  mass:15.999, radius:0.36, tm:54.0,   tb:90.0,   color:[1.00,0.27,0.27], lj_epsilon:1.58,  lj_sigma:3.1, category:Category::Gas,        description:"Жизненно необходимый газ." },
    Element { symbol:"F",  name_ru:"Фтор",      atomic_number:9,  mass:18.998, radius:0.32, tm:53.0,   tb:85.0,   color:[1.00,0.67,0.00], lj_epsilon:0.99,  lj_sigma:2.9, category:Category::Gas,        description:"Самый активный неметалл." },
    Element { symbol:"Ne", name_ru:"Неон",      atomic_number:10, mass:20.18,  radius:0.35, tm:24.0,   tb:27.0,   color:[0.27,1.00,0.80], lj_epsilon:0.31,  lj_sigma:2.8, category:Category::Gas,        description:"Инертный газ, используется в трубках." },
    Element { symbol:"Na", name_ru:"Натрий",    atomic_number:11, mass:22.990, radius:0.52, tm:371.0,  tb:1156.0, color:[0.80,0.67,0.40], lj_epsilon:1.12,  lj_sigma:2.9, category:Category::Metal,      description:"Щелочной металл, реагирует с водой." },
    Element { symbol:"Mg", name_ru:"Магний",    atomic_number:12, mass:24.305, radius:0.48, tm:923.0,  tb:1363.0, color:[0.27,0.73,0.27], lj_epsilon:1.51,  lj_sigma:2.7, category:Category::Metal,      description:"Лёгкий конструкционный металл." },
    Element { symbol:"Al", name_ru:"Алюминий",  atomic_number:13, mass:26.982, radius:0.46, tm:933.0,  tb:2792.0, color:[0.73,0.73,0.80], lj_epsilon:2.70,  lj_sigma:2.9, category:Category::Metal,      description:"Самый распространённый металл в коре." },
    Element { symbol:"Si", name_ru:"Кремний",   atomic_number:14, mass:28.086, radius:0.44, tm:1687.0, tb:3538.0, color:[0.60,0.40,0.67], lj_epsilon:2.10,  lj_sigma:3.8, category:Category::NonMetal,   description:"Основа полупроводников." },
    Element { symbol:"P",  name_ru:"Фосфор",    atomic_number:15, mass:30.974, radius:0.42, tm:317.0,  tb:550.0,  color:[1.00,0.40,0.13], lj_epsilon:1.73,  lj_sigma:3.7, category:Category::NonMetal,   description:"Важен для ДНК и костей." },
    Element { symbol:"S",  name_ru:"Сера",      atomic_number:16, mass:32.06,  radius:0.42, tm:388.0,  tb:718.0,  color:[0.87,0.87,0.13], lj_epsilon:1.73,  lj_sigma:3.6, category:Category::NonMetal,   description:"Жёлтое твёрдое вещество." },
    Element { symbol:"Cl", name_ru:"Хлор",      atomic_number:17, mass:35.453, radius:0.40, tm:172.0,  tb:239.0,  color:[0.60,0.93,0.27], lj_epsilon:1.23,  lj_sigma:3.5, category:Category::Gas,        description:"Жёлто-зелёный ядовитый газ." },
    Element { symbol:"Ar", name_ru:"Аргон",     atomic_number:18, mass:39.948, radius:0.45, tm:84.0,   tb:87.0,   color:[0.53,0.80,1.00], lj_epsilon:1.65,  lj_sigma:3.4, category:Category::Gas,        description:"Инертный газ для симуляции ЛД." },
    Element { symbol:"K",  name_ru:"Калий",     atomic_number:19, mass:39.098, radius:0.58, tm:336.0,  tb:1032.0, color:[0.80,0.53,0.53], lj_epsilon:0.94,  lj_sigma:3.6, category:Category::Metal,      description:"Мягкий щелочной металл." },
    Element { symbol:"Ca", name_ru:"Кальций",   atomic_number:20, mass:40.078, radius:0.56, tm:1115.0, tb:1757.0, color:[0.67,0.80,0.67], lj_epsilon:1.83,  lj_sigma:3.1, category:Category::Metal,      description:"Основа костей и зубов." },
    Element { symbol:"Ti", name_ru:"Титан",     atomic_number:22, mass:47.867, radius:0.52, tm:1941.0, tb:3560.0, color:[0.53,0.67,0.80], lj_epsilon:3.62,  lj_sigma:2.9, category:Category::Metal,      description:"Прочный лёгкий металл." },
    Element { symbol:"Cr", name_ru:"Хром",      atomic_number:24, mass:51.996, radius:0.50, tm:2180.0, tb:2944.0, color:[0.27,0.80,0.67], lj_epsilon:4.10,  lj_sigma:2.6, category:Category::Metal,      description:"Твёрдый блестящий металл." },
    Element { symbol:"Fe", name_ru:"Железо",    atomic_number:26, mass:55.845, radius:0.50, tm:1811.0, tb:3134.0, color:[0.80,0.53,0.40], lj_epsilon:6.04,  lj_sigma:2.4, category:Category::Metal,      description:"Самый используемый металл." },
    Element { symbol:"Ni", name_ru:"Никель",    atomic_number:28, mass:58.693, radius:0.49, tm:1728.0, tb:3186.0, color:[0.40,0.73,0.67], lj_epsilon:5.47,  lj_sigma:2.5, category:Category::Metal,      description:"Ферромагнитный металл." },
    Element { symbol:"Cu", name_ru:"Медь",      atomic_number:29, mass:63.546, radius:0.48, tm:1358.0, tb:2835.0, color:[1.00,0.67,0.27], lj_epsilon:5.29,  lj_sigma:2.3, category:Category::Metal,      description:"Отличный проводник тепла и тока." },
    Element { symbol:"Zn", name_ru:"Цинк",      atomic_number:30, mass:65.38,  radius:0.47, tm:693.0,  tb:1180.0, color:[0.67,0.73,0.80], lj_epsilon:1.96,  lj_sigma:2.8, category:Category::Metal,      description:"Используется для оцинковки стали." },
    Element { symbol:"Br", name_ru:"Бром",      atomic_number:35, mass:79.904, radius:0.48, tm:266.0,  tb:332.0,  color:[0.80,0.27,0.13], lj_epsilon:1.64,  lj_sigma:3.8, category:Category::NonMetal,   description:"Единственный жидкий неметалл при 25°C." },
    Element { symbol:"Kr", name_ru:"Криптон",   atomic_number:36, mass:83.798, radius:0.50, tm:115.0,  tb:120.0,  color:[0.53,0.60,1.00], lj_epsilon:1.13,  lj_sigma:3.6, category:Category::Gas,        description:"Тяжёлый инертный газ." },
    Element { symbol:"Ag", name_ru:"Серебро",   atomic_number:47, mass:107.87, radius:0.53, tm:1235.0, tb:2435.0, color:[0.87,0.87,0.93], lj_epsilon:4.30,  lj_sigma:2.6, category:Category::Metal,      description:"Лучший проводник среди металлов." },
    Element { symbol:"Sn", name_ru:"Олово",     atomic_number:50, mass:118.71, radius:0.55, tm:505.0,  tb:2875.0, color:[0.60,0.67,0.67], lj_epsilon:3.07,  lj_sigma:3.0, category:Category::Metal,      description:"Используется в припоях." },
    Element { symbol:"Xe", name_ru:"Ксенон",    atomic_number:54, mass:131.29, radius:0.54, tm:161.0,  tb:165.0,  color:[0.67,0.73,1.00], lj_epsilon:2.54,  lj_sigma:4.0, category:Category::Gas,        description:"Тяжёлый газ для ионных двигателей." },
    Element { symbol:"Ba", name_ru:"Барий",     atomic_number:56, mass:137.33, radius:0.60, tm:1000.0, tb:2170.0, color:[0.40,0.67,0.80], lj_epsilon:2.06,  lj_sigma:3.6, category:Category::Metal,      description:"Щелочноземельный металл." },
    Element { symbol:"W",  name_ru:"Вольфрам",  atomic_number:74, mass:183.84, radius:0.54, tm:3695.0, tb:5828.0, color:[0.47,0.53,0.60], lj_epsilon:8.90,  lj_sigma:2.7, category:Category::Metal,      description:"Наивысшая Tm среди металлов." },
    Element { symbol:"Pt", name_ru:"Платина",   atomic_number:78, mass:195.08, radius:0.55, tm:2041.0, tb:4098.0, color:[0.80,0.80,0.87], lj_epsilon:6.91,  lj_sigma:2.8, category:Category::Metal,      description:"Благородный металл-катализатор." },
    Element { symbol:"Au", name_ru:"Золото",    atomic_number:79, mass:196.97, radius:0.56, tm:1337.0, tb:3129.0, color:[1.00,0.84,0.00], lj_epsilon:7.61,  lj_sigma:2.9, category:Category::Metal,      description:"Тяжёлый инертный металл." },
    Element { symbol:"Pb", name_ru:"Свинец",    atomic_number:82, mass:207.2,  radius:0.58, tm:600.0,  tb:2022.0, color:[0.53,0.60,0.53], lj_epsilon:2.53,  lj_sigma:3.5, category:Category::Metal,      description:"Тяжёлый мягкий металл." },
    Element { symbol:"U",  name_ru:"Уран",      atomic_number:92, mass:238.03, radius:0.62, tm:1405.0, tb:4404.0, color:[0.53,1.00,0.27], lj_epsilon:8.00,  lj_sigma:3.0, category:Category::Radioactive, description:"Радиоактивный тяжёлый металл." },
];

/// Найти элемент по символу
pub fn find_element(symbol: &str) -> Option<&'static Element> {
    ELEMENTS.iter().find(|e| e.symbol == symbol)
}

/// Получить элемент по индексу
pub fn get_element(index: usize) -> &'static Element {
    &ELEMENTS[index.min(ELEMENTS.len() - 1)]
}

/// Кол-во элементов
pub fn element_count() -> usize {
    ELEMENTS.len()
}

/// Смешанные параметры ЛД для пары атомов (правило Лоренца-Бертло)
pub fn mixed_lj(e1: &Element, e2: &Element, eps_scale: f32) -> (f32, f32) {
    let eps = (e1.lj_epsilon * e2.lj_epsilon).sqrt() * eps_scale;
    let sigma = (e1.lj_sigma + e2.lj_sigma) * 0.5;
    (eps, sigma)
}
