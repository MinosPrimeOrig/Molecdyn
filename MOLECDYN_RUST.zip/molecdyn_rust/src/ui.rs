// ════════════════════════════════════════════════════════════════════
//  UI — Интерфейс (главное меню, симуляция, гайд)
//  Реализован через immediate-mode рендер поверх WGPU
//  На мобильных — нижний таб-бар с шторками
// ════════════════════════════════════════════════════════════════════

use glam::Vec2;
use winit::dpi::PhysicalSize;
use winit::event::WindowEvent;

use crate::simulation::{AppScreen, Scenario, UiAction};
use crate::input::InputState;
use crate::elements::{ELEMENTS, element_count};

// ── Параметры UI ─────────────────────────────────────────────────────
pub struct UiParams {
    pub target_temperature: f32,
    pub gravity: f32,
    pub eps_scale: f32,
    pub trail_len: usize,
    pub selected_element: usize,
    pub show_bonds: bool,
    pub show_trails: bool,
    pub show_heat: bool,
    pub show_orbit: bool,
    pub paused: bool,
    pub mode_3d: bool,
}

impl Default for UiParams {
    fn default() -> Self {
        Self {
            target_temperature: 300.0,
            gravity: 0.0,
            eps_scale: 1.0,
            trail_len: 20,
            selected_element: 17, // Ar
            show_bonds: true,
            show_trails: true,
            show_heat: true,
            show_orbit: true,
            paused: false,
            mode_3d: false,
        }
    }
}

// ── Активная шторка (мобайл) ─────────────────────────────────────────
#[derive(Debug, Clone, PartialEq)]
pub enum MobileSheet {
    None,
    Elements,
    Scenarios,
    Settings,
    Stats,
}

pub struct Ui {
    pub screen: AppScreen,
    pub params: UiParams,
    pub screen_size: PhysicalSize<u32>,
    pub is_mobile: bool,
    pub mobile_sheet: MobileSheet,
    pub sheet_offset: f32,  // анимация (0.0 = закрыта, 1.0 = открыта)
}

impl Ui {
    pub fn new(size: PhysicalSize<u32>) -> Self {
        let is_mobile = size.width < 768;
        Self {
            screen: AppScreen::Menu,
            params: UiParams::default(),
            screen_size: size,
            is_mobile,
            mobile_sheet: MobileSheet::None,
            sheet_offset: 0.0,
        }
    }

    pub fn resize(&mut self, size: PhysicalSize<u32>) {
        self.screen_size = size;
        self.is_mobile = size.width < 768;
    }

    /// Возвращает true если событие было потреблено UI
    pub fn handle_window_event(&mut self, event: &WindowEvent) -> bool {
        // Базовая обработка — детальная реализация через egui или custom 2D
        false
    }

    /// Обработка ввода, возвращает список действий для симуляции
    pub fn process_input(&mut self, input: &mut InputState, dt: f32) -> Vec<UiAction> {
        let mut actions = Vec::new();

        // Анимация шторки
        let target = if self.mobile_sheet != MobileSheet::None { 1.0f32 } else { 0.0f32 };
        self.sheet_offset += (target - self.sheet_offset) * (dt * 12.0).min(1.0);

        // Пробел = пауза
        if input.space_pressed {
            self.params.paused = !self.params.paused;
            actions.push(UiAction::TogglePause);
        }

        // ESC = главное меню
        if input.escape_pressed {
            actions.push(UiAction::GoToScreen(AppScreen::Menu));
        }

        actions
    }

    // ── Описание UI для рендера ───────────────────────────────────────
    // Эти методы возвращают данные для 2D рендера (прямоугольники, текст)
    // Реальный рендер реализуется через egui (см. ниже) или custom renderer

    pub fn top_bar_height(&self) -> f32 {
        if self.screen_size.height < 600 { 42.0 } else { 48.0 }
    }

    pub fn bottom_bar_height(&self) -> f32 {
        if self.is_mobile { 62.0 } else { 0.0 }
    }

    pub fn left_panel_width(&self) -> f32 {
        if self.is_mobile { 0.0 } else { 220.0 }
    }

    pub fn right_panel_width(&self) -> f32 {
        if self.is_mobile { 0.0 } else { 200.0 }
    }
}

// ════════════════════════════════════════════════════════════════════
//  EGUI ИНТЕГРАЦИЯ
//  egui — самый популярный immediate-mode GUI для Rust
//  Рендерится поверх WGPU через egui-wgpu
// ════════════════════════════════════════════════════════════════════
//
//  В полной реализации здесь подключается:
//  use egui_winit::State as EguiWinitState;
//  use egui_wgpu::Renderer as EguiRenderer;
//
//  Пример рисования кнопки:
//  ui.add(egui::Button::new("⏸ ПАУЗА")
//      .fill(Color32::from_rgba_premultiplied(0, 30, 50, 220))
//  );
//
//  Для мобильного: egui автоматически масштабирует под DPI
//  и поддерживает touch события через winit.
// ════════════════════════════════════════════════════════════════════

// ── Вспомогательные функции UI ────────────────────────────────────────

/// Проверяет попадание точки в прямоугольник
pub fn hit_rect(pos: Vec2, rect_x: f32, rect_y: f32, rect_w: f32, rect_h: f32) -> bool {
    pos.x >= rect_x && pos.x <= rect_x + rect_w &&
    pos.y >= rect_y && pos.y <= rect_y + rect_h
}

/// Название сценария на русском
pub fn scenario_name(s: Scenario) -> &'static str {
    match s {
        Scenario::IdealGas  => "☁ Идеальный Газ",
        Scenario::Liquid    => "≋ Жидкость",
        Scenario::Crystal   => "◆ Кристалл",
        Scenario::Plasma    => "✦ Плазма",
        Scenario::Brownian  => "◯ Броуновское",
        Scenario::BinaryMix => "⊕ Смесь",
    }
}

pub const ALL_SCENARIOS: &[Scenario] = &[
    Scenario::IdealGas,
    Scenario::Liquid,
    Scenario::Crystal,
    Scenario::Plasma,
    Scenario::Brownian,
    Scenario::BinaryMix,
];
