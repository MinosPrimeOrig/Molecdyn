// ════════════════════════════════════════════════════════════════════
//  ФИЗИКА — Верле + Леннард-Джонс + термостат Берендсена
//  Параллельное вычисление сил через rayon (все CPU ядра)
// ════════════════════════════════════════════════════════════════════

use glam::Vec3;
use rayon::prelude::*;
use std::sync::atomic::{AtomicU32, Ordering};

use crate::elements::{Element, ELEMENTS, mixed_lj};

// ── Атом ────────────────────────────────────────────────────────────
#[derive(Debug, Clone)]
pub struct Atom {
    // Позиция (в условных единицах)
    pub pos: Vec3,
    // Скорость
    pub vel: Vec3,
    // Ускорение (текущий шаг)
    pub acc: Vec3,
    // Ускорение (предыдущий шаг) — для Верле
    pub acc_prev: Vec3,
    // Индекс элемента в ELEMENTS
    pub element_idx: usize,
    // Масса (кешированная из элемента)
    pub mass: f32,
    // Радиус (кешированный)
    pub radius: f32,
    // Хвост (последние N позиций)
    pub trail: Vec<Vec3>,
    // Угол орбитального электрона
    pub orbital_angle: f32,
    pub orbital_speed: f32,
    // Игрок (0=нет, 1=первый, 2=второй) для мультиплеера
    pub player: u8,
    // Уникальный ID
    pub id: u32,
}

static ATOM_COUNTER: AtomicU32 = AtomicU32::new(0);

impl Atom {
    pub fn new(pos: Vec3, vel: Vec3, element_idx: usize) -> Self {
        let el = &ELEMENTS[element_idx];
        Self {
            pos, vel,
            acc: Vec3::ZERO,
            acc_prev: Vec3::ZERO,
            element_idx,
            mass: el.mass,
            radius: el.radius,
            trail: Vec::with_capacity(32),
            orbital_angle: rand_f32() * std::f32::consts::TAU,
            orbital_speed: 0.04 + rand_f32() * 0.04,
            player: 0,
            id: ATOM_COUNTER.fetch_add(1, Ordering::Relaxed),
        }
    }

    #[inline]
    pub fn speed(&self) -> f32 {
        self.vel.length()
    }

    #[inline]
    pub fn kinetic_energy(&self) -> f32 {
        0.5 * self.mass * self.vel.length_squared()
    }

    pub fn element(&self) -> &'static Element {
        &ELEMENTS[self.element_idx]
    }
}

// Быстрый псевдорандом (xorshift)
fn rand_f32() -> f32 {
    use std::time::{SystemTime, UNIX_EPOCH};
    static SEED: AtomicU32 = AtomicU32::new(12345);
    let mut x = SEED.fetch_add(
        SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().subsec_nanos(),
        Ordering::Relaxed
    );
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    SEED.store(x, Ordering::Relaxed);
    (x as f32) / (u32::MAX as f32)
}

// ── Параметры интегратора ────────────────────────────────────────────
pub struct PhysicsParams {
    pub target_temperature: f32,
    pub gravity: f32,         // ускорение вниз (по Y)
    pub eps_scale: f32,       // масштаб epsilon ЛД
    pub box_size: f32,        // полуразмер куба симуляции
    pub thermostat_tau: f32,  // время релаксации термостата (с)
    pub trail_len: usize,
    pub mode_3d: bool,
}

impl Default for PhysicsParams {
    fn default() -> Self {
        Self {
            target_temperature: 300.0,
            gravity: 0.0,
            eps_scale: 1.0,
            box_size: 6.0,
            thermostat_tau: 0.1,
            trail_len: 20,
            mode_3d: false,
        }
    }
}

// ── Результат шага физики ────────────────────────────────────────────
#[derive(Default, Clone)]
pub struct PhysicsStats {
    pub temperature: f32,
    pub kinetic_energy: f32,
    pub potential_energy: f32,
    pub bond_count: u32,
    pub avg_speed: f32,
    pub max_speed: f32,
}

// ════════════════════════════════════════════════════════════════════
//  Потенциал Леннарда-Джонса
//  U(r) = 4ε [ (σ/r)¹² − (σ/r)⁶ ]
//  F(r) = -dU/dr = 24ε/r² [ 2(σ/r)¹² − (σ/r)⁶ ]
// ════════════════════════════════════════════════════════════════════
#[inline(always)]
fn lj_force(
    pi: Vec3, pj: Vec3,
    eps: f32, sigma: f32,
) -> (Vec3, f32) {
    let r_vec = pj - pi;
    let r2 = r_vec.length_squared();

    // Отсечка: не считаем слишком близкие и далёкие атомы
    let r_cut = sigma * 2.8;
    if r2 < 0.01 || r2 > r_cut * r_cut {
        return (Vec3::ZERO, 0.0);
    }

    let inv_r2 = sigma * sigma / r2;
    let inv_r6 = inv_r2 * inv_r2 * inv_r2;
    let inv_r12 = inv_r6 * inv_r6;

    // Сила (скалярный коэффициент)
    let f_scalar = eps * (48.0 * inv_r12 - 24.0 * inv_r6) / r2;
    let force = r_vec * f_scalar;

    // Потенциальная энергия пары
    let pe = 4.0 * eps * (inv_r12 - inv_r6);

    (force, pe)
}

// ════════════════════════════════════════════════════════════════════
//  Шаг интегрирования velocity-Verlet + параллельные силы
// ════════════════════════════════════════════════════════════════════
pub fn step(atoms: &mut Vec<Atom>, params: &PhysicsParams, dt: f32) -> PhysicsStats {
    let n = atoms.len();
    if n == 0 {
        return PhysicsStats::default();
    }

    let box_h = params.box_size;

    // ── 1. Полшага скорости + обновление позиций ─────────────────────
    for a in atoms.iter_mut() {
        a.vel += a.acc * (dt * 0.5);
        a.pos += a.vel * dt;

        // Trail
        if params.trail_len > 0 {
            a.trail.push(a.pos);
            if a.trail.len() > params.trail_len {
                a.trail.remove(0);
            }
        } else {
            a.trail.clear();
        }
    }

    // ── 2. Вычисление сил параллельно (rayon) ────────────────────────
    // Разбиваем попарно: каждый поток считает свой диапазон i
    // Используем схему "редукции" через Vec атомарных аккумуляторов

    let mut forces: Vec<Vec3> = vec![Vec3::ZERO; n];
    let mut total_pe = 0.0f32;
    let mut bond_count = 0u32;

    // Для корректной параллельности — считаем по строкам матрицы сил
    // (каждый поток обрабатывает один i, читает все j > i)
    // Сначала параллельно собираем (fi, pe_i) без записи в fj,
    // потом отдельным проходом суммируем.

    // Снимки позиций/масс для потокобезопасного чтения
    let positions: Vec<Vec3> = atoms.iter().map(|a| a.pos).collect();
    let el_indices: Vec<usize> = atoms.iter().map(|a| a.element_idx).collect();

    // Параллельный расчёт сил (каждый поток — одна строка i)
    let row_results: Vec<(Vec<(usize, Vec3)>, f32, u32)> = (0..n)
        .into_par_iter()
        .map(|i| {
            let ei = &ELEMENTS[el_indices[i]];
            let mut contributions: Vec<(usize, Vec3)> = Vec::new();
            let mut pe_sum = 0.0f32;
            let mut bonds = 0u32;

            for j in (i + 1)..n {
                let ej = &ELEMENTS[el_indices[j]];
                let (eps, sigma) = mixed_lj(ei, ej, params.eps_scale);

                let (f, pe) = lj_force(positions[i], positions[j], eps, sigma);
                if f != Vec3::ZERO {
                    contributions.push((j, f)); // fj += f (нужно инвертировать для fi)
                    pe_sum += pe;

                    // Детектирование связей (r < 1.5σ)
                    let r2 = (positions[j] - positions[i]).length_squared();
                    if r2 < sigma * sigma * 2.25 {
                        bonds += 1;
                    }
                }
            }
            (contributions, pe_sum, bonds)
        })
        .collect();

    // Сборка результатов в forces[]
    for (i, (contribs, pe, bonds)) in row_results.into_iter().enumerate() {
        total_pe += pe;
        bond_count += bonds;
        for (j, f) in contribs {
            forces[i] -= f / atoms[i].mass; // fi = -F/mi
            forces[j] += f / atoms[j].mass; // fj = +F/mj
        }
        // Гравитация
        forces[i].y += params.gravity * 0.005;
    }

    // ── 3. Второй полшаг скорости ────────────────────────────────────
    let mut total_ke = 0.0f32;
    let mut total_speed = 0.0f32;
    let mut max_speed = 0.0f32;

    for (i, a) in atoms.iter_mut().enumerate() {
        a.acc = forces[i];
        a.vel += a.acc * (dt * 0.5);
        let spd = a.speed();
        total_ke += a.kinetic_energy();
        total_speed += spd;
        if spd > max_speed { max_speed = spd; }
    }

    // ── 4. Термостат Берендсена ───────────────────────────────────────
    let cur_t = if n > 1 { total_ke / n as f32 } else { 0.0 };
    if cur_t > 0.0001 && params.target_temperature > 0.0 {
        let lambda = (1.0 + (dt / params.thermostat_tau)
            * (params.target_temperature * 0.3 / cur_t - 1.0)
        ).sqrt().clamp(0.5, 2.5);
        for a in atoms.iter_mut() {
            a.vel *= lambda;
        }
        // Пересчёт KE после масштабирования
        total_ke *= lambda * lambda;
    }

    // ── 5. Граничные условия (упругие стенки) ───────────────────────
    for a in atoms.iter_mut() {
        macro_rules! bounce {
            ($pos:expr, $vel:expr, $lo:expr, $hi:expr) => {
                if $pos < $lo { $pos = $lo; $vel = $vel.abs(); }
                if $pos > $hi { $pos = $hi; $vel = -$vel.abs(); }
            };
        }
        bounce!(a.pos.x, a.vel.x, -box_h, box_h);
        bounce!(a.pos.y, a.vel.y, -box_h, box_h);
        if params.mode_3d {
            bounce!(a.pos.z, a.vel.z, -box_h, box_h);
        } else {
            a.pos.z = 0.0;
            a.vel.z = 0.0;
        }
    }

    // ── 6. Статистика ────────────────────────────────────────────────
    let temperature = cur_t * 18.0; // переводим в K (эвристический коэффициент)

    PhysicsStats {
        temperature,
        kinetic_energy: total_ke,
        potential_energy: total_pe,
        bond_count,
        avg_speed: if n > 0 { total_speed / n as f32 } else { 0.0 },
        max_speed,
    }
}

// ════════════════════════════════════════════════════════════════════
//  Взрыв
// ════════════════════════════════════════════════════════════════════
pub fn explode(atoms: &mut Vec<Atom>, force: f32) {
    use rand::Rng;
    let mut rng = rand::thread_rng();
    for a in atoms.iter_mut() {
        let d = a.pos.length() + 0.5;
        let dir = a.pos.normalize_or_zero();
        a.vel += dir * (force / d)
            + Vec3::new(
                rng.gen_range(-1.0..1.0) * force * 0.3,
                rng.gen_range(-1.0..1.0) * force * 0.3,
                rng.gen_range(-1.0..1.0) * force * 0.3,
            );
    }
}
