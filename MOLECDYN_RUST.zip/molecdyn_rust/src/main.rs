// ════════════════════════════════════════════════════════════════════
//  MOLECDYN — Молекулярная Динамика
//  Rust + WGPU | 5000+ частиц | EXE + APK
// ════════════════════════════════════════════════════════════════════

#![allow(dead_code, unused_variables)]

mod elements;
mod physics;
mod renderer;
mod ui;
mod simulation;
mod scenarios;
mod input;
mod audio;

use winit::{
    event::{Event, WindowEvent, ElementState, MouseButton, Touch, TouchPhase},
    event_loop::{ControlFlow, EventLoop},
    window::WindowBuilder,
    dpi::PhysicalSize,
};
use std::time::Instant;

// Android точка входа
#[cfg(target_os = "android")]
#[no_mangle]
fn android_main(app: winit::platform::android::activity::AndroidApp) {
    use winit::platform::android::EventLoopBuilderExtAndroid;
    env_logger::init();
    let event_loop = EventLoop::builder()
        .with_android_app(app)
        .build()
        .unwrap();
    run(event_loop);
}

// Desktop точка входа
#[cfg(not(target_os = "android"))]
fn main() {
    env_logger::Builder::from_env(
        env_logger::Env::default().default_filter_or("warn")
    ).init();

    let event_loop = EventLoop::new().unwrap();
    run(event_loop);
}

// ── Общий запуск ────────────────────────────────────────────────────
fn run(event_loop: EventLoop<()>) {
    let window = WindowBuilder::new()
        .with_title("MOLECDYN // Молекулярная Динамика")
        .with_inner_size(PhysicalSize::new(1280u32, 800u32))
        .with_min_inner_size(PhysicalSize::new(480u32, 320u32))
        .with_resizable(true)
        .build(&event_loop)
        .expect("Не удалось создать окно");

    // Async инициализация WGPU
    let mut state = pollster::block_on(
        app_state::AppState::new(&window)
    );

    let mut last_time = Instant::now();
    let mut fps_timer = Instant::now();
    let mut frame_count = 0u32;

    event_loop.run(move |event, target| {
        target.set_control_flow(ControlFlow::Poll);

        match event {
            Event::WindowEvent { event, .. } => {
                // Передаём в UI обработчик
                if !state.ui.handle_window_event(&event) {
                    match event {
                        WindowEvent::CloseRequested => target.exit(),
                        WindowEvent::Resized(size) => state.resize(size),
                        WindowEvent::RedrawRequested => {
                            let now = Instant::now();
                            let dt = now.duration_since(last_time).as_secs_f32()
                                .min(0.05); // кап 20fps min для стабильности
                            last_time = now;

                            // FPS счётчик
                            frame_count += 1;
                            if fps_timer.elapsed().as_secs_f32() >= 1.0 {
                                state.fps = frame_count;
                                frame_count = 0;
                                fps_timer = Instant::now();
                            }

                            state.update(dt);
                            match state.render() {
                                Ok(_) => {}
                                Err(wgpu::SurfaceError::Lost) => state.resize(state.size),
                                Err(wgpu::SurfaceError::OutOfMemory) => target.exit(),
                                Err(e) => log::error!("Ошибка рендера: {:?}", e),
                            }
                        }
                        WindowEvent::MouseInput { state: btn_state, button, .. } => {
                            state.input.on_mouse_button(button, btn_state);
                        }
                        WindowEvent::CursorMoved { position, .. } => {
                            state.input.on_mouse_move(position.x as f32, position.y as f32);
                        }
                        WindowEvent::MouseWheel { delta, .. } => {
                            state.input.on_scroll(delta);
                        }
                        WindowEvent::Touch(touch) => {
                            state.input.on_touch(touch);
                        }
                        WindowEvent::KeyboardInput { event, .. } => {
                            state.input.on_key(event);
                        }
                        _ => {}
                    }
                }
            }
            Event::AboutToWait => {
                window.request_redraw();
            }
            _ => {}
        }
    }).unwrap();
}

// ── AppState — главное состояние приложения ─────────────────────────
mod app_state {
    use super::*;
    use crate::{
        simulation::Simulation,
        renderer::Renderer,
        ui::{Ui, Screen},
        input::InputState,
        elements::ELEMENTS,
    };
    use winit::dpi::PhysicalSize;

    pub struct AppState {
        pub surface: wgpu::Surface,
        pub device: wgpu::Device,
        pub queue: wgpu::Queue,
        pub config: wgpu::SurfaceConfiguration,
        pub size: PhysicalSize<u32>,
        pub renderer: Renderer,
        pub simulation: Simulation,
        pub ui: Ui,
        pub input: InputState,
        pub fps: u32,
        pub mode_3d: bool,
    }

    impl AppState {
        pub async fn new(window: &winit::window::Window) -> Self {
            let size = window.inner_size();

            // WGPU Instance — автоматически выбирает Vulkan/DX12/Metal/GLES
            let instance = wgpu::Instance::new(wgpu::InstanceDescriptor {
                backends: wgpu::Backends::all(),
                ..Default::default()
            });

            let surface = unsafe {
                instance.create_surface(window).unwrap()
            };

            let adapter = instance.request_adapter(&wgpu::RequestAdapterOptions {
                power_preference: wgpu::PowerPreference::HighPerformance,
                compatible_surface: Some(&surface),
                force_fallback_adapter: false,
            }).await.unwrap();

            let (device, queue) = adapter.request_device(
                &wgpu::DeviceDescriptor {
                    label: Some("MOLECDYN Device"),
                    features: wgpu::Features::empty(),
                    limits: if cfg!(target_arch = "wasm32") {
                        wgpu::Limits::downlevel_webgl2_defaults()
                    } else {
                        wgpu::Limits::default()
                    },
                },
                None,
            ).await.unwrap();

            let surface_caps = surface.get_capabilities(&adapter);
            let format = surface_caps.formats.iter()
                .copied()
                .find(|f| f.is_srgb())
                .unwrap_or(surface_caps.formats[0]);

            let config = wgpu::SurfaceConfiguration {
                usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
                format,
                width: size.width,
                height: size.height,
                present_mode: wgpu::PresentMode::Fifo, // VSync
                alpha_mode: surface_caps.alpha_modes[0],
                view_formats: vec![],
            };
            surface.configure(&device, &config);

            let renderer = Renderer::new(&device, &queue, &config, size);
            let simulation = Simulation::new();
            let ui = Ui::new(size);
            let input = InputState::new();

            Self {
                surface, device, queue, config, size,
                renderer, simulation, ui, input,
                fps: 0, mode_3d: false,
            }
        }

        pub fn resize(&mut self, new_size: PhysicalSize<u32>) {
            if new_size.width > 0 && new_size.height > 0 {
                self.size = new_size;
                self.config.width = new_size.width;
                self.config.height = new_size.height;
                self.surface.configure(&self.device, &self.config);
                self.renderer.resize(&self.device, new_size);
                self.ui.resize(new_size);
            }
        }

        pub fn update(&mut self, dt: f32) {
            // Обработка UI событий (кнопки, слайдеры)
            let ui_actions = self.ui.process_input(&mut self.input, dt);

            // Применяем действия UI к симуляции
            for action in ui_actions {
                self.simulation.apply_action(action, self.mode_3d);
            }

            // 3D орбита камеры
            if self.mode_3d {
                self.renderer.camera.update_orbit(&self.input, dt);
            }

            // Шаг физики (несколько подшагов для точности)
            if !self.simulation.paused {
                let substeps = if self.simulation.atom_count() > 2000 { 1 } else { 2 };
                for _ in 0..substeps {
                    self.simulation.step(dt / substeps as f32);
                }
            }

            self.simulation.update_stats(dt);
            self.input.end_frame();
        }

        pub fn render(&mut self) -> Result<(), wgpu::SurfaceError> {
            let output = self.surface.get_current_texture()?;
            let view = output.texture.create_view(&wgpu::TextureViewDescriptor::default());

            let mut encoder = self.device.create_command_encoder(
                &wgpu::CommandEncoderDescriptor { label: Some("Main Encoder") }
            );

            // Основной рендер прохода
            self.renderer.render_frame(
                &self.device,
                &self.queue,
                &mut encoder,
                &view,
                &self.simulation,
                &self.ui,
                self.mode_3d,
                self.fps,
            );

            self.queue.submit(std::iter::once(encoder.finish()));
            output.present();
            Ok(())
        }
    }
}
