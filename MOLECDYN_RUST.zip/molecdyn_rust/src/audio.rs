// ════════════════════════════════════════════════════════════════════
//  AUDIO — звуковые эффекты (заглушка)
//  Для добавления звука использовать crate: rodio или kira
// ════════════════════════════════════════════════════════════════════

pub struct Audio;

impl Audio {
    pub fn new() -> Self { Self }
    pub fn play_explosion(&self) {}
    pub fn play_phase_change(&self) {}
}
