// ════════════════════════════════════════════════════════════════════
//  RENDERER — WGPU GPU рендер
//  Инстансный рендер шаров, связи, хвосты, фон, текст
// ════════════════════════════════════════════════════════════════════

use glam::{Mat4, Vec3, Vec4, Quat};
use wgpu::util::DeviceExt;
use winit::dpi::PhysicalSize;

use crate::simulation::Simulation;
use crate::ui::Ui;
use crate::elements::Phase;

// ── Матрица камеры ────────────────────────────────────────────────────
pub struct Camera {
    pub theta: f32,
    pub phi: f32,
    pub distance: f32,
    pub fov_y: f32,
}

impl Camera {
    pub fn new() -> Self {
        Self { theta: 0.2, phi: 1.1, distance: 14.0, fov_y: 55.0f32.to_radians() }
    }

    pub fn update_orbit(&mut self, input: &crate::input::InputState, _dt: f32) {
        if input.mouse_drag {
            self.theta -= input.mouse_delta.x * 0.007;
            self.phi = (self.phi - input.mouse_delta.y * 0.007)
                .clamp(0.1, std::f32::consts::PI - 0.1);
        }
        self.distance = (self.distance + input.scroll_delta * 0.02).clamp(4.0, 28.0);
    }

    pub fn view_matrix(&self) -> Mat4 {
        let eye = Vec3::new(
            self.distance * self.phi.sin() * self.theta.sin(),
            self.distance * self.phi.cos(),
            self.distance * self.phi.sin() * self.theta.cos(),
        );
        Mat4::look_at_rh(eye, Vec3::ZERO, Vec3::Y)
    }

    pub fn proj_matrix_3d(&self, aspect: f32) -> Mat4 {
        Mat4::perspective_rh(self.fov_y, aspect, 0.01, 100.0)
    }

    pub fn proj_matrix_2d(box_size: f32, aspect: f32) -> Mat4 {
        Mat4::orthographic_rh(
            -box_size * aspect, box_size * aspect,
            -box_size, box_size,
            -100.0, 100.0,
        )
    }
}

// ── Инстанс атома (данные на GPU) ────────────────────────────────────
#[repr(C)]
#[derive(Copy, Clone, bytemuck::Pod, bytemuck::Zeroable)]
struct AtomInstance {
    position: [f32; 3],
    radius: f32,
    color: [f32; 3],
    emissive: f32,
}

// ── Вершина сферы ────────────────────────────────────────────────────
#[repr(C)]
#[derive(Copy, Clone, bytemuck::Pod, bytemuck::Zeroable)]
struct SphereVertex {
    position: [f32; 3],
    normal: [f32; 3],
}

// ── Uniform буфер (матрицы + параметры) ─────────────────────────────
#[repr(C)]
#[derive(Copy, Clone, bytemuck::Pod, bytemuck::Zeroable)]
struct Uniforms {
    view_proj: [f32; 16],
    light_dir: [f32; 3],
    _pad: f32,
    ambient: f32,
    _pad2: [f32; 3],
}

// ── WGPU шейдер (WGSL) ───────────────────────────────────────────────
const ATOM_SHADER: &str = r#"
struct Uniforms {
    view_proj: mat4x4<f32>,
    light_dir: vec3<f32>,
    ambient: f32,
};

struct AtomInstance {
    @location(2) position: vec3<f32>,
    @location(3) radius: f32,
    @location(4) color: vec3<f32>,
    @location(5) emissive: f32,
};

struct VertexInput {
    @location(0) local_pos: vec3<f32>,
    @location(1) normal: vec3<f32>,
};

struct VertexOutput {
    @builtin(position) clip_pos: vec4<f32>,
    @location(0) color: vec3<f32>,
    @location(1) emissive: f32,
    @location(2) normal: vec3<f32>,
    @location(3) world_pos: vec3<f32>,
};

@group(0) @binding(0) var<uniform> uniforms: Uniforms;

@vertex
fn vs_main(vert: VertexInput, inst: AtomInstance) -> VertexOutput {
    let world_pos = vert.local_pos * inst.radius + inst.position;
    var out: VertexOutput;
    out.clip_pos = uniforms.view_proj * vec4<f32>(world_pos, 1.0);
    out.color = inst.color;
    out.emissive = inst.emissive;
    out.normal = vert.normal;
    out.world_pos = world_pos;
    return out;
}

@fragment
fn fs_main(in: VertexOutput) -> @location(0) vec4<f32> {
    let n = normalize(in.normal);
    let l = normalize(-uniforms.light_dir);
    let diff = max(dot(n, l), 0.0);

    // Specular Blinn-Phong
    let v = normalize(vec3<f32>(0.0, 0.0, 1.0) - in.world_pos);
    let h = normalize(l + v);
    let spec = pow(max(dot(n, h), 0.0), 32.0) * 0.4;

    let lighting = uniforms.ambient + diff * 0.7 + spec;
    let base = in.color * lighting;
    let final_color = mix(base, in.color, in.emissive);

    return vec4<f32>(final_color, 1.0);
}
"#;

const BOND_SHADER: &str = r#"
@group(0) @binding(0) var<uniform> view_proj: mat4x4<f32>;

struct VertexInput {
    @location(0) position: vec3<f32>,
    @location(1) color: vec3<f32>,
    @location(2) alpha: f32,
};

struct VertexOutput {
    @builtin(position) clip_pos: vec4<f32>,
    @location(0) color: vec4<f32>,
};

@vertex
fn vs_main(in: VertexInput) -> VertexOutput {
    var out: VertexOutput;
    out.clip_pos = view_proj * vec4<f32>(in.position, 1.0);
    out.color = vec4<f32>(in.color, in.alpha);
    return out;
}

@fragment
fn fs_main(in: VertexOutput) -> @location(0) vec4<f32> {
    return in.color;
}
"#;

// ── Рендерер ─────────────────────────────────────────────────────────
pub struct Renderer {
    // Пайплайны
    atom_pipeline: wgpu::RenderPipeline,
    bond_pipeline: wgpu::RenderPipeline,

    // Геометрия сферы
    sphere_vertex_buf: wgpu::Buffer,
    sphere_index_buf: wgpu::Buffer,
    sphere_index_count: u32,

    // Инстансный буфер (заполняется каждый кадр)
    instance_buf: wgpu::Buffer,
    instance_capacity: usize,

    // Bond буфер (линии)
    bond_buf: wgpu::Buffer,
    bond_capacity: usize,

    // Trail буфер
    trail_buf: wgpu::Buffer,
    trail_capacity: usize,

    // Uniforms
    uniform_buf: wgpu::Buffer,
    uniform_bind_group: wgpu::BindGroup,

    // Depth texture
    depth_texture: wgpu::Texture,
    depth_view: wgpu::TextureView,

    pub camera: Camera,
    pub size: PhysicalSize<u32>,
    pub box_size: f32,
}

impl Renderer {
    pub fn new(
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        config: &wgpu::SurfaceConfiguration,
        size: PhysicalSize<u32>,
    ) -> Self {
        // Генерируем сферу (UV sphere)
        let (vertices, indices) = generate_sphere(14, 10);
        let sphere_vertex_buf = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("Sphere Vertices"),
            contents: bytemuck::cast_slice(&vertices),
            usage: wgpu::BufferUsages::VERTEX,
        });
        let sphere_index_buf = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("Sphere Indices"),
            contents: bytemuck::cast_slice(&indices),
            usage: wgpu::BufferUsages::INDEX,
        });

        // Uniform buffer
        let uniform_data = Uniforms {
            view_proj: Mat4::IDENTITY.to_cols_array(),
            light_dir: [-0.5f32, -0.8, -0.3],
            _pad: 0.0,
            ambient: 0.15,
            _pad2: [0.0; 3],
        };
        let uniform_buf = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("Uniforms"),
            contents: bytemuck::bytes_of(&uniform_data),
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
        });

        let bind_group_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("Uniform BGL"),
            entries: &[wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::VERTEX | wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Uniform,
                    has_dynamic_offset: false,
                    min_binding_size: None,
                },
                count: None,
            }],
        });
        let uniform_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("Uniform BG"),
            layout: &bind_group_layout,
            entries: &[wgpu::BindGroupEntry {
                binding: 0,
                resource: uniform_buf.as_entire_binding(),
            }],
        });

        // Instance buffer (5000 атомов с запасом)
        let instance_capacity = 8000;
        let instance_buf = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("Instances"),
            size: (instance_capacity * std::mem::size_of::<AtomInstance>()) as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        // Bond buffer
        let bond_capacity = 64000;
        let bond_buf = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("Bonds"),
            size: (bond_capacity * 4 * 7) as u64, // 7 f32 на вершину
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        // Trail buffer
        let trail_capacity = 128000;
        let trail_buf = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("Trails"),
            size: (trail_capacity * 4 * 7) as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        // Depth texture
        let (depth_texture, depth_view) = create_depth_texture(device, size);

        // Shader modules
        let atom_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("Atom Shader"),
            source: wgpu::ShaderSource::Wgsl(ATOM_SHADER.into()),
        });
        let bond_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("Bond Shader"),
            source: wgpu::ShaderSource::Wgsl(BOND_SHADER.into()),
        });

        let pipeline_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("Atom Pipeline Layout"),
            bind_group_layouts: &[&bind_group_layout],
            push_constant_ranges: &[],
        });

        // Atom render pipeline
        let atom_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("Atom Pipeline"),
            layout: Some(&pipeline_layout),
            vertex: wgpu::VertexState {
                module: &atom_shader,
                entry_point: "vs_main",
                buffers: &[
                    // Вершины сферы
                    wgpu::VertexBufferLayout {
                        array_stride: std::mem::size_of::<SphereVertex>() as u64,
                        step_mode: wgpu::VertexStepMode::Vertex,
                        attributes: &wgpu::vertex_attr_array![0 => Float32x3, 1 => Float32x3],
                    },
                    // Инстансные данные
                    wgpu::VertexBufferLayout {
                        array_stride: std::mem::size_of::<AtomInstance>() as u64,
                        step_mode: wgpu::VertexStepMode::Instance,
                        attributes: &wgpu::vertex_attr_array![
                            2 => Float32x3, 3 => Float32, 4 => Float32x3, 5 => Float32
                        ],
                    },
                ],
            },
            fragment: Some(wgpu::FragmentState {
                module: &atom_shader,
                entry_point: "fs_main",
                targets: &[Some(wgpu::ColorTargetState {
                    format: config.format,
                    blend: Some(wgpu::BlendState::REPLACE),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
            }),
            primitive: wgpu::PrimitiveState {
                topology: wgpu::PrimitiveTopology::TriangleList,
                cull_mode: Some(wgpu::Face::Back),
                ..Default::default()
            },
            depth_stencil: Some(wgpu::DepthStencilState {
                format: wgpu::TextureFormat::Depth32Float,
                depth_write_enabled: true,
                depth_compare: wgpu::CompareFunction::Less,
                stencil: wgpu::StencilState::default(),
                bias: wgpu::DepthBiasState::default(),
            }),
            multisample: wgpu::MultisampleState::default(),
            multiview: None,
        });

        // Bond pipeline (Lines)
        let bond_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("Bond Pipeline"),
            layout: Some(&pipeline_layout),
            vertex: wgpu::VertexState {
                module: &bond_shader,
                entry_point: "vs_main",
                buffers: &[wgpu::VertexBufferLayout {
                    array_stride: (7 * 4) as u64,
                    step_mode: wgpu::VertexStepMode::Vertex,
                    attributes: &wgpu::vertex_attr_array![0 => Float32x3, 1 => Float32x3, 2 => Float32],
                }],
            },
            fragment: Some(wgpu::FragmentState {
                module: &bond_shader,
                entry_point: "fs_main",
                targets: &[Some(wgpu::ColorTargetState {
                    format: config.format,
                    blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
            }),
            primitive: wgpu::PrimitiveState {
                topology: wgpu::PrimitiveTopology::LineList,
                ..Default::default()
            },
            depth_stencil: Some(wgpu::DepthStencilState {
                format: wgpu::TextureFormat::Depth32Float,
                depth_write_enabled: false,
                depth_compare: wgpu::CompareFunction::Less,
                stencil: wgpu::StencilState::default(),
                bias: wgpu::DepthBiasState::default(),
            }),
            multisample: wgpu::MultisampleState::default(),
            multiview: None,
        });

        Self {
            atom_pipeline, bond_pipeline,
            sphere_vertex_buf, sphere_index_buf,
            sphere_index_count: indices.len() as u32,
            instance_buf, instance_capacity,
            bond_buf, bond_capacity,
            trail_buf, trail_capacity,
            uniform_buf, uniform_bind_group,
            depth_texture, depth_view,
            camera: Camera::new(),
            size,
            box_size: 6.0,
        }
    }

    pub fn resize(&mut self, device: &wgpu::Device, new_size: PhysicalSize<u32>) {
        self.size = new_size;
        let (dt, dv) = create_depth_texture(device, new_size);
        self.depth_texture = dt;
        self.depth_view = dv;
    }

    pub fn render_frame(
        &mut self,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        encoder: &mut wgpu::CommandEncoder,
        view: &wgpu::TextureView,
        sim: &Simulation,
        ui: &Ui,
        mode_3d: bool,
        fps: u32,
    ) {
        let w = self.size.width as f32;
        let h = self.size.height as f32;
        let aspect = w / h;

        // View-Projection матрица
        let vp = if mode_3d {
            self.camera.proj_matrix_3d(aspect) * self.camera.view_matrix()
        } else {
            Camera::proj_matrix_2d(self.box_size, aspect)
        };

        // Обновляем uniform
        let uniform_data = Uniforms {
            view_proj: vp.to_cols_array(),
            light_dir: [-0.5, -0.8, -0.3],
            _pad: 0.0,
            ambient: if mode_3d { 0.15 } else { 0.35 },
            _pad2: [0.0; 3],
        };
        queue.write_buffer(&self.uniform_buf, 0, bytemuck::bytes_of(&uniform_data));

        // Готовим инстансы атомов
        let atoms = &sim.atoms;
        let mut max_speed = 0.0f32;
        for a in atoms { let s = a.speed(); if s > max_speed { max_speed = s; } }

        let instances: Vec<AtomInstance> = atoms.iter().map(|a| {
            let t = (a.speed() / max_speed.max(0.001)).min(1.0);
            let color = if true { // showHeat
                // HSL: hue от 240° (синий) до 0° (красный)
                let hue = (1.0 - t) * 0.66;
                hsv_to_rgb(hue, 1.0, 0.55 + t * 0.2)
            } else {
                let c = a.element().color;
                [c[0], c[1], c[2]]
            };
            let phase = a.element().phase(sim.stats.temperature);
            let emissive = match phase {
                Phase::Plasma => 0.65,
                Phase::Gas    => 0.14,
                _             => 0.06,
            };
            AtomInstance {
                position: [a.pos.x, a.pos.y, if mode_3d { a.pos.z } else { 0.0 }],
                radius: a.radius,
                color,
                emissive,
            }
        }).collect();

        if !instances.is_empty() {
            queue.write_buffer(&self.instance_buf, 0, bytemuck::cast_slice(&instances));
        }

        // Готовим данные связей
        let mut bond_data: Vec<f32> = Vec::new();
        let atom_count = atoms.len();
        for i in 0..atom_count.min(500) { // ограничение для производительности
            for j in (i+1)..atom_count.min(500) {
                let ai = &atoms[i];
                let aj = &atoms[j];
                let dx = aj.pos.x - ai.pos.x;
                let dy = aj.pos.y - ai.pos.y;
                let dz = aj.pos.z - ai.pos.z;
                let r = (dx*dx + dy*dy + dz*dz).sqrt();
                let sig = (ai.element().lj_sigma + aj.element().lj_sigma) * 0.5;
                if r < sig * 2.8 {
                    let alpha = ((1.0 - r / (sig * 2.8)) * 0.6).max(0.0);
                    // Вершина i
                    bond_data.extend_from_slice(&[ai.pos.x, ai.pos.y, if mode_3d {ai.pos.z} else {0.0}, 0.0, 0.84, 1.0, alpha]);
                    // Вершина j
                    bond_data.extend_from_slice(&[aj.pos.x, aj.pos.y, if mode_3d {aj.pos.z} else {0.0}, 0.0, 0.84, 1.0, alpha]);
                }
            }
        }
        if !bond_data.is_empty() {
            queue.write_buffer(&self.bond_buf, 0, bytemuck::cast_slice(&bond_data));
        }

        // Render pass
        let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
            label: Some("Main Pass"),
            color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                view,
                resolve_target: None,
                ops: wgpu::Operations {
                    load: wgpu::LoadOp::Clear(wgpu::Color { r: 0.012, g: 0.039, b: 0.059, a: 1.0 }),
                    store: wgpu::StoreOp::Store,
                },
            })],
            depth_stencil_attachment: Some(wgpu::RenderPassDepthStencilAttachment {
                view: &self.depth_view,
                depth_ops: Some(wgpu::Operations {
                    load: wgpu::LoadOp::Clear(1.0),
                    store: wgpu::StoreOp::Store,
                }),
                stencil_ops: None,
            }),
            timestamp_writes: None,
            occlusion_query_set: None,
        });

        // Рисуем связи
        if !bond_data.is_empty() {
            pass.set_pipeline(&self.bond_pipeline);
            pass.set_bind_group(0, &self.uniform_bind_group, &[]);
            pass.set_vertex_buffer(0, self.bond_buf.slice(..));
            pass.draw(0..(bond_data.len() / 7) as u32, 0..1);
        }

        // Рисуем атомы (инстансинг)
        if !instances.is_empty() {
            pass.set_pipeline(&self.atom_pipeline);
            pass.set_bind_group(0, &self.uniform_bind_group, &[]);
            pass.set_vertex_buffer(0, self.sphere_vertex_buf.slice(..));
            pass.set_vertex_buffer(1, self.instance_buf.slice(..));
            pass.set_index_buffer(self.sphere_index_buf.slice(..), wgpu::IndexFormat::Uint16);
            pass.draw_indexed(0..self.sphere_index_count, 0, 0..instances.len() as u32);
        }

        drop(pass);
        // UI рисуется поверх через отдельный 2D слой (egui или custom)
    }
}

// ── Генерация UV-сферы ────────────────────────────────────────────────
fn generate_sphere(rings: u32, sectors: u32) -> (Vec<SphereVertex>, Vec<u16>) {
    let mut vertices = Vec::new();
    let mut indices: Vec<u16> = Vec::new();
    let pi = std::f32::consts::PI;

    for r in 0..=rings {
        let phi = pi * r as f32 / rings as f32;
        for s in 0..=sectors {
            let theta = 2.0 * pi * s as f32 / sectors as f32;
            let x = phi.sin() * theta.cos();
            let y = phi.cos();
            let z = phi.sin() * theta.sin();
            vertices.push(SphereVertex {
                position: [x, y, z],
                normal: [x, y, z],
            });
        }
    }
    for r in 0..rings {
        for s in 0..sectors {
            let a = (r * (sectors + 1) + s) as u16;
            let b = (r * (sectors + 1) + s + 1) as u16;
            let c = ((r + 1) * (sectors + 1) + s) as u16;
            let d = ((r + 1) * (sectors + 1) + s + 1) as u16;
            indices.extend_from_slice(&[a, c, b, b, c, d]);
        }
    }
    (vertices, indices)
}

fn create_depth_texture(device: &wgpu::Device, size: PhysicalSize<u32>) -> (wgpu::Texture, wgpu::TextureView) {
    let texture = device.create_texture(&wgpu::TextureDescriptor {
        label: Some("Depth Texture"),
        size: wgpu::Extent3d { width: size.width, height: size.height, depth_or_array_layers: 1 },
        mip_level_count: 1,
        sample_count: 1,
        dimension: wgpu::TextureDimension::D2,
        format: wgpu::TextureFormat::Depth32Float,
        usage: wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::TEXTURE_BINDING,
        view_formats: &[],
    });
    let view = texture.create_view(&wgpu::TextureViewDescriptor::default());
    (texture, view)
}

fn hsv_to_rgb(h: f32, s: f32, v: f32) -> [f32; 3] {
    let i = (h * 6.0) as u32;
    let f = h * 6.0 - i as f32;
    let p = v * (1.0 - s);
    let q = v * (1.0 - f * s);
    let t = v * (1.0 - (1.0 - f) * s);
    match i % 6 {
        0 => [v, t, p],
        1 => [q, v, p],
        2 => [p, v, t],
        3 => [p, q, v],
        4 => [t, p, v],
        _ => [v, p, q],
    }
}
