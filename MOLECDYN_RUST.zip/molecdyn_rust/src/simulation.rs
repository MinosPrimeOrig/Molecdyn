// ════════════════════════════════════════════════════════════════════
//  SIMULATION — менеджер симуляции
// ════════════════════════════════════════════════════════════════════

use glam::Vec3;
use rand::Rng;

use crate::elements::{ELEMENTS, element_count, Phase};
use crate::physics::{Atom, PhysicsParams, PhysicsStats, step, explode};

// ── Экран ────────────────────────────────────────────────────────────
#[derive(Debug, Clone, PartialEq)]
pub enum AppScreen {
    Menu,
    Simulation,
    Guide,
    ElementsTable,
}

// ── Действие из UI ───────────────────────────────────────────────────
#[derive(Debug, Clone)]
pub enum UiAction {
    SetTemperature(f32),
    SetGravity(f32),
    SetEpsilon(f32),
    SetTrailLen(usize),
    SetElement(usize),
    LoadScenario(Scenario),
    TogglePause,
    Explode,
    Clear,
    SetMode3d(bool),
    AddAtom { pos: Vec3, element_idx: usize, player: u8 },
    SelectAtom(u32),   // по id
    DeselectAtom,
    GoToScreen(AppScreen),
}

// ── Сценарии ─────────────────────────────────────────────────────────
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum Scenario {
    IdealGas,
    Liquid,
    Crystal,
    Plasma,
    Brownian,
    BinaryMix,
}

// ── История для графиков ─────────────────────────────────────────────
pub struct History {
    pub temperature: Vec<f32>,
    pub kinetic: Vec<f32>,
    pub potential: Vec<f32>,
    pub max_len: usize,
}

impl History {
    pub fn new(max_len: usize) -> Self {
        Self {
            temperature: Vec::with_capacity(max_len),
            kinetic: Vec::with_capacity(max_len),
            potential: Vec::with_capacity(max_len),
            max_len,
        }
    }
    pub fn push(&mut self, t: f32, ke: f32, pe: f32) {
        fn push_capped(v: &mut Vec<f32>, val: f32, max: usize) {
            v.push(val);
            if v.len() > max { v.remove(0); }
        }
        push_capped(&mut self.temperature, t, self.max_len);
        push_capped(&mut self.kinetic, ke, self.max_len);
        push_capped(&mut self.potential, pe, self.max_len);
    }
}

// ── Основной менеджер ────────────────────────────────────────────────
pub struct Simulation {
    pub atoms: Vec<Atom>,
    pub params: PhysicsParams,
    pub stats: PhysicsStats,
    pub history: History,
    pub paused: bool,
    pub selected_atom_id: Option<u32>,
    pub selected_element_idx: usize,
    pub screen: AppScreen,
    pub multiplayer: bool,
    pub p1_element_idx: usize,
    pub p2_element_idx: usize,
    frame: u32,
}

impl Simulation {
    pub fn new() -> Self {
        let mut sim = Self {
            atoms: Vec::new(),
            params: PhysicsParams::default(),
            stats: PhysicsStats::default(),
            history: History::new(250),
            paused: false,
            selected_atom_id: None,
            selected_element_idx: 17, // Ar — индекс в ELEMENTS
            screen: AppScreen::Menu,
            multiplayer: false,
            p1_element_idx: 17, // Ar
            p2_element_idx: 9,  // Ne
            frame: 0,
        };
        sim
    }

    pub fn atom_count(&self) -> usize {
        self.atoms.len()
    }

    pub fn step(&mut self, dt: f32) {
        self.stats = step(&mut self.atoms, &self.params, dt);
        self.frame += 1;

        // Обновляем историю каждые 4 кадра
        if self.frame % 4 == 0 {
            self.history.push(
                self.stats.temperature,
                self.stats.kinetic_energy,
                self.stats.potential_energy,
            );
        }

        // Обновляем орбитальные углы выбранного атома
        if let Some(id) = self.selected_atom_id {
            if let Some(a) = self.atoms.iter_mut().find(|a| a.id == id) {
                a.orbital_angle += a.orbital_speed;
            }
        }
    }

    pub fn update_stats(&mut self, _dt: f32) {}

    pub fn apply_action(&mut self, action: UiAction, mode_3d: bool) {
        match action {
            UiAction::SetTemperature(t)  => { self.params.target_temperature = t; }
            UiAction::SetGravity(g)      => { self.params.gravity = g; }
            UiAction::SetEpsilon(e)      => { self.params.eps_scale = e; }
            UiAction::SetTrailLen(n)     => { self.params.trail_len = n; }
            UiAction::SetElement(idx)    => { self.selected_element_idx = idx; }
            UiAction::LoadScenario(sc)   => { self.load_scenario(sc); }
            UiAction::TogglePause        => { self.paused = !self.paused; }
            UiAction::Explode            => { explode(&mut self.atoms, 16.0); }
            UiAction::Clear              => { self.clear(); }
            UiAction::SetMode3d(b)       => {
                self.params.mode_3d = b;
                if !b {
                    for a in self.atoms.iter_mut() {
                        a.pos.z = 0.0; a.vel.z = 0.0;
                    }
                }
            }
            UiAction::AddAtom { pos, element_idx, player } => {
                let mut rng = rand::thread_rng();
                let vel_range = 1.5f32;
                let vel = Vec3::new(
                    rng.gen_range(-vel_range..vel_range),
                    rng.gen_range(-vel_range..vel_range),
                    if mode_3d { rng.gen_range(-vel_range..vel_range) } else { 0.0 },
                );
                let mut atom = Atom::new(pos, vel, element_idx);
                atom.player = player;
                self.atoms.push(atom);
            }
            UiAction::SelectAtom(id) => {
                self.selected_atom_id = Some(id);
            }
            UiAction::DeselectAtom => {
                self.selected_atom_id = None;
            }
            UiAction::GoToScreen(screen) => {
                self.screen = screen;
            }
        }
    }

    pub fn clear(&mut self) {
        self.atoms.clear();
        self.selected_atom_id = None;
    }

    pub fn selected_atom(&self) -> Option<&Atom> {
        self.selected_atom_id.and_then(|id|
            self.atoms.iter().find(|a| a.id == id)
        )
    }

    pub fn current_phase(&self) -> Phase {
        let el = &ELEMENTS[self.selected_element_idx];
        el.phase(self.stats.temperature)
    }

    // ── Сценарии ─────────────────────────────────────────────────────
    pub fn load_scenario(&mut self, scenario: Scenario) {
        self.clear();
        let mut rng = rand::thread_rng();
        let b = self.params.box_size;
        let r = |rng: &mut rand::rngs::ThreadRng, scale: f32|
            rng.gen_range(-b * scale..b * scale);
        let rv = |rng: &mut rand::rngs::ThreadRng, s: f32|
            rng.gen_range(-s..s);
        let mode3d = self.params.mode_3d;

        match scenario {
            Scenario::IdealGas => {
                self.params.target_temperature = 300.0;
                let idx = self.selected_element_idx;
                for _ in 0..80 {
                    let pos = Vec3::new(r(&mut rng,0.9), r(&mut rng,0.9), if mode3d {r(&mut rng,0.9)} else {0.0});
                    let vel = Vec3::new(rv(&mut rng,4.0), rv(&mut rng,4.0), if mode3d {rv(&mut rng,4.0)} else {0.0});
                    self.atoms.push(Atom::new(pos, vel, idx));
                }
            }
            Scenario::Liquid => {
                self.params.target_temperature = 90.0;
                let idx = self.selected_element_idx;
                for _ in 0..100 {
                    let pos = Vec3::new(r(&mut rng,0.8), r(&mut rng,0.6), if mode3d {r(&mut rng,0.6)} else {0.0});
                    let vel = Vec3::new(rv(&mut rng,1.5), rv(&mut rng,1.5), if mode3d {rv(&mut rng,1.5)} else {0.0});
                    self.atoms.push(Atom::new(pos, vel, idx));
                }
            }
            Scenario::Crystal => {
                self.params.target_temperature = 10.0;
                // Fe (индекс 22)
                let fe_idx = ELEMENTS.iter().position(|e| e.symbol == "Fe").unwrap_or(22);
                if mode3d {
                    let sp = 1.2f32;
                    let side = 5i32;
                    let off = (side - 1) as f32 * sp * 0.5;
                    for ix in 0..side { for iy in 0..side { for iz in 0..side {
                        let pos = Vec3::new(ix as f32 * sp - off, iy as f32 * sp - off, iz as f32 * sp - off);
                        let vel = Vec3::new(rv(&mut rng,0.06), rv(&mut rng,0.06), rv(&mut rng,0.06));
                        self.atoms.push(Atom::new(pos, vel, fe_idx));
                    }}}
                } else {
                    let cols = 10i32; let rows = 8i32; let sp = 1.2f32;
                    for r_ in 0..rows { for c in 0..cols {
                        let ox = if r_ % 2 == 0 { 0.0 } else { sp * 0.5 };
                        let pos = Vec3::new((c - cols/2) as f32 * sp + ox, (r_ - rows/2) as f32 * sp * 0.87, 0.0);
                        let vel = Vec3::new(rv(&mut rng,0.05), rv(&mut rng,0.05), 0.0);
                        self.atoms.push(Atom::new(pos, vel, fe_idx));
                    }}
                }
            }
            Scenario::Plasma => {
                self.params.target_temperature = 5000.0;
                let h_idx = ELEMENTS.iter().position(|e| e.symbol == "H").unwrap_or(0);
                for _ in 0..60 {
                    let pos = Vec3::new(r(&mut rng,0.9), r(&mut rng,0.9), if mode3d {r(&mut rng,0.9)} else {0.0});
                    let vel = Vec3::new(rv(&mut rng,14.0), rv(&mut rng,14.0), if mode3d {rv(&mut rng,14.0)} else {0.0});
                    self.atoms.push(Atom::new(pos, vel, h_idx));
                }
            }
            Scenario::Brownian => {
                self.params.target_temperature = 300.0;
                let au_idx = ELEMENTS.iter().position(|e| e.symbol == "Au").unwrap_or(33);
                let he_idx = ELEMENTS.iter().position(|e| e.symbol == "He").unwrap_or(1);
                // Большой атом в центре
                let mut big = Atom::new(Vec3::ZERO, Vec3::ZERO, au_idx);
                big.mass = 800.0;
                big.radius = 1.0;
                self.atoms.push(big);
                // Маленькие атомы вокруг
                for _ in 0..70 {
                    let pos = Vec3::new(r(&mut rng,0.9), r(&mut rng,0.9), if mode3d {r(&mut rng,0.9)} else {0.0});
                    let vel = Vec3::new(rv(&mut rng,5.0), rv(&mut rng,5.0), if mode3d {rv(&mut rng,5.0)} else {0.0});
                    self.atoms.push(Atom::new(pos, vel, he_idx));
                }
            }
            Scenario::BinaryMix => {
                self.params.target_temperature = 200.0;
                let ar_idx = ELEMENTS.iter().position(|e| e.symbol == "Ar").unwrap_or(17);
                let ne_idx = ELEMENTS.iter().position(|e| e.symbol == "Ne").unwrap_or(9);
                for i in 0..90 {
                    let idx = if i % 2 == 0 { ar_idx } else { ne_idx };
                    let pos = Vec3::new(r(&mut rng,0.9), r(&mut rng,0.9), if mode3d {r(&mut rng,0.9)} else {0.0});
                    let vel = Vec3::new(rv(&mut rng,3.0), rv(&mut rng,3.0), if mode3d {rv(&mut rng,3.0)} else {0.0});
                    self.atoms.push(Atom::new(pos, vel, idx));
                }
            }
        }
    }
}
