// ════════════════════════════════════════════════════════════════════
//  INPUT — мышь, клавиатура, тач (Android / Desktop)
// ════════════════════════════════════════════════════════════════════

use glam::Vec2;
use winit::event::{
    MouseButton, ElementState, MouseScrollDelta, Touch, TouchPhase, KeyEvent,
    MouseScrollDelta::*,
};

#[derive(Debug, Clone)]
pub struct TouchPoint {
    pub id: u64,
    pub pos: Vec2,
    pub phase: TouchPhase,
}

pub struct InputState {
    // Мышь
    pub mouse_pos: Vec2,
    pub mouse_delta: Vec2,
    pub mouse_drag: bool,
    pub mouse_left_pressed: bool,   // только в этом кадре
    pub mouse_left_held: bool,
    pub mouse_right_pressed: bool,
    pub scroll_delta: f32,

    // Touch
    pub touches: Vec<TouchPoint>,
    pub tap_pos: Option<Vec2>,      // короткий тап
    pub pinch_scale: f32,           // масштаб щипка (1.0 = нет изменений)

    // Клавиатура
    pub space_pressed: bool,
    pub escape_pressed: bool,

    // Внутренние
    prev_mouse_pos: Vec2,
    left_down_time: std::time::Instant,
    pinch_initial_dist: f32,
    pinch_current_dist: f32,
}

impl InputState {
    pub fn new() -> Self {
        Self {
            mouse_pos: Vec2::ZERO,
            mouse_delta: Vec2::ZERO,
            mouse_drag: false,
            mouse_left_pressed: false,
            mouse_left_held: false,
            mouse_right_pressed: false,
            scroll_delta: 0.0,
            touches: Vec::new(),
            tap_pos: None,
            pinch_scale: 1.0,
            space_pressed: false,
            escape_pressed: false,
            prev_mouse_pos: Vec2::ZERO,
            left_down_time: std::time::Instant::now(),
            pinch_initial_dist: 0.0,
            pinch_current_dist: 0.0,
        }
    }

    pub fn on_mouse_button(&mut self, button: MouseButton, state: ElementState) {
        match (button, state) {
            (MouseButton::Left, ElementState::Pressed) => {
                self.mouse_left_held = true;
                self.mouse_left_pressed = true;
                self.mouse_drag = false;
                self.left_down_time = std::time::Instant::now();
            }
            (MouseButton::Left, ElementState::Released) => {
                self.mouse_left_held = false;
                // Короткий клик — добавляем атом / выбираем
                if self.left_down_time.elapsed().as_millis() < 200 && !self.mouse_drag {
                    self.tap_pos = Some(self.mouse_pos);
                }
                self.mouse_drag = false;
            }
            (MouseButton::Right, ElementState::Pressed) => {
                self.mouse_right_pressed = true;
            }
            _ => {}
        }
    }

    pub fn on_mouse_move(&mut self, x: f32, y: f32) {
        self.prev_mouse_pos = self.mouse_pos;
        self.mouse_pos = Vec2::new(x, y);
        self.mouse_delta = self.mouse_pos - self.prev_mouse_pos;

        if self.mouse_left_held && self.mouse_delta.length() > 2.0 {
            self.mouse_drag = true;
        }
    }

    pub fn on_scroll(&mut self, delta: MouseScrollDelta) {
        self.scroll_delta = match delta {
            LineDelta(_, y) => y * 3.0,
            PixelDelta(pos) => pos.y as f32 * 0.1,
        };
    }

    pub fn on_touch(&mut self, touch: Touch) {
        let pos = Vec2::new(touch.location.x as f32, touch.location.y as f32);

        match touch.phase {
            TouchPhase::Started => {
                self.touches.push(TouchPoint { id: touch.id, pos, phase: touch.phase });

                if self.touches.len() == 2 {
                    let p0 = self.touches[0].pos;
                    let p1 = self.touches[1].pos;
                    self.pinch_initial_dist = (p1 - p0).length();
                    self.pinch_current_dist = self.pinch_initial_dist;
                }
            }
            TouchPhase::Moved => {
                if let Some(tp) = self.touches.iter_mut().find(|t| t.id == touch.id) {
                    tp.pos = pos;
                    tp.phase = touch.phase;
                }
                // Pinch zoom
                if self.touches.len() == 2 {
                    let p0 = self.touches[0].pos;
                    let p1 = self.touches[1].pos;
                    let new_dist = (p1 - p0).length();
                    if self.pinch_current_dist > 0.0 {
                        self.pinch_scale = self.pinch_current_dist / new_dist;
                    }
                    self.pinch_current_dist = new_dist;
                    // Drag (single touch only)
                    self.mouse_drag = true;
                } else if self.touches.len() == 1 {
                    let prev = self.mouse_pos;
                    self.mouse_pos = pos;
                    self.mouse_delta = self.mouse_pos - prev;
                    self.mouse_drag = true;
                }
            }
            TouchPhase::Ended | TouchPhase::Cancelled => {
                // Tap если касание короткое
                if self.touches.len() == 1 && !self.mouse_drag {
                    self.tap_pos = Some(pos);
                }
                self.touches.retain(|t| t.id != touch.id);
                if self.touches.is_empty() {
                    self.mouse_drag = false;
                    self.pinch_scale = 1.0;
                }
            }
        }
    }

    pub fn on_key(&mut self, event: KeyEvent) {
        use winit::keyboard::{KeyCode, PhysicalKey};
        if event.state == ElementState::Pressed {
            match event.physical_key {
                PhysicalKey::Code(KeyCode::Space)  => self.space_pressed = true,
                PhysicalKey::Code(KeyCode::Escape) => self.escape_pressed = true,
                _ => {}
            }
        }
    }

    /// Вызывается в конце каждого кадра — сбрасываем однокадровые события
    pub fn end_frame(&mut self) {
        self.mouse_left_pressed = false;
        self.mouse_right_pressed = false;
        self.scroll_delta = 0.0;
        self.mouse_delta = Vec2::ZERO;
        self.tap_pos = None;
        self.space_pressed = false;
        self.escape_pressed = false;
        self.pinch_scale = 1.0;
    }

    /// NDC координаты тапа (для рейкастинга)
    pub fn tap_ndc(&self, screen_size: (f32, f32)) -> Option<Vec2> {
        self.tap_pos.map(|p| Vec2::new(
            p.x / screen_size.0 * 2.0 - 1.0,
            -(p.y / screen_size.1 * 2.0 - 1.0),
        ))
    }
}
